<?php

include_once "class.globalinfo.php";
$gi = new globalInfo();

$listVar = ["serverhost","serveruser","serverpww","dbname"];

$serverhost = "localhost";
$serveruser = "root";
$serverpww = "";
$dbname = "mobelanja";

// $serverhost = "localhost";
// $serveruser = "cvsayape_mobelanja";
// $serverpww = "5kdYqZNCFLWerpMFZLjP";
// $dbname = "cvsayape_mobelanja";


### UPDATE DATA  ###
foreach ($listVar as $var) {
  echo $gi->addVar($var,$$var,"_GLOBAL_","UPDATE").PHP_EOL;
}

echo "Test DB Name: ". $gi->getVar("dbname");



?>
